import 'package:flutter/material.dart';
//import 'package:firebase_core/firebase_core.dart';
//import 'package:cloud_firestore/cloud_firestore.dart';
//import 'package:geoflutterfire/geoflutterfire.dart';
//import 'package:location/location.dart';
//import 'package:google_maps_flutter/google_maps_flutter.dart';
//import 'package:rxdart/rxdart.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        body: Center(
          child: Text(
            'Text q'
          )
        ),
      ),
    );
  }
}
